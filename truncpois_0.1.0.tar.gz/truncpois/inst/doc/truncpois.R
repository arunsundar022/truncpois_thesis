## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  fig.width  = 7,
  fig.height = 5,
  fig.align  = "center",
  fig.show   = "hold",
  collapse   = TRUE,
  comment    = "#>",
  warning    = FALSE,
  message    = FALSE
)

## ----install, eval=FALSE------------------------------------------------------
# # Install the development version from GitHub
# # install.packages("pak")
# pak::pak("arunsundar022/truncpois")

## ----load---------------------------------------------------------------------
library(truncpois)

## ----pmf-table----------------------------------------------------------------
x          <- 0:12
p_pois     <- stats::dpois(x, lambda = 5)
p_trunc    <- dtruncpois(x, lambda = 5, a = 2, b = 10)

round(rbind(x = x, Poisson = p_pois, Truncated = p_trunc), 4)

## ----pmf-plot, fig.height=4.5-------------------------------------------------
plottruncpois(lambda = 5, a = 2, b = 10)

## ----pmf-log------------------------------------------------------------------
dtruncpois(100, lambda = 100, a = 50, b = 150, log = TRUE)

## ----cdf-table----------------------------------------------------------------
q          <- 0:12
cdf_pois   <- stats::ppois(q, lambda = 5)
cdf_trunc  <- ptruncpois(q, lambda = 5, a = 2, b = 10)

round(rbind(q = q, Poisson = cdf_pois, Truncated = cdf_trunc), 4)

## ----cdf-plot, fig.height=4.5-------------------------------------------------
plottruncpois(lambda = 5, a = 2, b = 10, type = "cdf")

## ----cdf-uppertail------------------------------------------------------------
# Upper-tail probability P(X > 7 | 2 <= X <= 10)
ptruncpois(7, lambda = 5, a = 2, b = 10, lower.tail = FALSE)

## ----quantile-----------------------------------------------------------------
p <- seq(0.1, 0.9, by = 0.2)
q <- qtruncpois(p, lambda = 5, a = 2, b = 10)
rbind(p = p, q = q)

## ----quantile-roundtrip-------------------------------------------------------
cdf_at_q <- ptruncpois(q, lambda = 5, a = 2, b = 10)
rbind(target_p = p, quantile = q, cdf_at_q = round(cdf_at_q, 4))

## ----quantile-plot, fig.height=4.5--------------------------------------------
plottruncpois(lambda = 5, a = 2, b = 10, type = "quantile")

## ----random-gen---------------------------------------------------------------
set.seed(2026)
x_direct    <- rtruncpois(1000, lambda = 3, a = 1, b = Inf, method = "direct")
x_inversion <- rtruncpois(1000, lambda = 3, a = 1, b = Inf, method = "inversion")
x_bounded   <- rtruncpois(1000, lambda = 3, a = 1, b = Inf, method = "bounded")

## ----random-compare-----------------------------------------------------------
rbind(
  direct     = c(min = min(x_direct),    max = max(x_direct),    mean = mean(x_direct)),
  inversion  = c(min = min(x_inversion), max = max(x_inversion), mean = mean(x_inversion)),
  bounded    = c(min = min(x_bounded),   max = max(x_bounded),   mean = mean(x_bounded)),
  theoretical = c(min = NA, max = NA,    mean = extruncpois(3, a = 1))
)

## ----random-large-lambda------------------------------------------------------
set.seed(42)
samples <- rtruncpois(10, lambda = 100, a = 90, b = 110, method = "inversion")
samples

## ----random-microbenchmark, eval=requireNamespace("microbenchmark", quietly = TRUE)----
microbenchmark::microbenchmark(
  direct    = rtruncpois(1000, lambda = 3, a = 1, b = Inf, method = "direct"),
  inversion = rtruncpois(1000, lambda = 3, a = 1, b = Inf, method = "inversion"),
  bounded   = rtruncpois(1000, lambda = 3, a = 1, b = Inf, method = "bounded"),
  times = 50
)

## ----mean-ztp-----------------------------------------------------------------
lambda_val <- 2
c(lambda = lambda_val, "E[X | X >= 1]" = extruncpois(lambda_val, a = 1))

## ----mean-convergence, fig.height=4.5-----------------------------------------
bounds <- 1:15
means  <- sapply(bounds, function(b) extruncpois(lambda = 5, a = 0, b = b))

plot(bounds, means, type = "b", pch = 19, col = "steelblue",
     ylab = "E[X | 0 <= X <= b]", xlab = "Upper Bound b",
     main = "Mean of Right-Truncated Poisson(λ=5) vs Upper Bound")
abline(h = 5, lty = 2, col = "firebrick", lwd = 1.5)
legend("bottomright", legend = c("Truncated mean", "λ = 5"),
       col = c("steelblue", "firebrick"), pch = c(19, NA),
       lty = c(1, 2), bty = "n")

## ----variance-----------------------------------------------------------------
lambda_val <- 5
c("Untruncated variance (= lambda)" = lambda_val,
  "Truncated variance [2, 8]"       = vartruncpois(lambda_val, a = 2, b = 8))

## ----variance-sim-------------------------------------------------------------
set.seed(99)
samples <- rtruncpois(20000, lambda = 5, a = 2, b = 8)
c("Simulated variance"   = round(var(samples), 4),
  "Theoretical variance" = round(vartruncpois(5, a = 2, b = 8), 4))

## ----median-------------------------------------------------------------------
c("Median (default bounds)" = medtruncpois(lambda = 5),
  "Median [1, Inf]"         = medtruncpois(lambda = 3, a = 1),
  "Median [2, 10]"          = medtruncpois(lambda = 5, a = 2, b = 10),
  "Median (low lambda=0.5)" = medtruncpois(lambda = 0.5, a = 0, b = 5))

## ----mode-unique--------------------------------------------------------------
modtruncpois(lambda = 2.5, a = 0, b = 10) # unique mode: floor(2.5) = 2

## ----mode-tie-----------------------------------------------------------------
modtruncpois(lambda = 5, a = 0, b = 10)   # lambda = 5 is an integer, so 4 and 5 tie

## ----mode-clamped-------------------------------------------------------------
modtruncpois(lambda = 1, a = 3, b = 10)   # clamped to a = 3

## ----together-simulate--------------------------------------------------------
set.seed(2026)
lambda_true <- 6
a <- 2; b <- 15
x <- rtruncpois(5000, lambda = lambda_true, a = a, b = b)

fit <- mletruncpois(x, a = a, b = b)
fit$lambda

## ----together-plot, fig.height=4.5--------------------------------------------
support   <- a:b
tab       <- table(factor(x, levels = support))
emp_prop  <- as.numeric(tab) / length(x)
theo_prop <- dtruncpois(support, lambda = fit$lambda, a = a, b = b)

barplot(rbind(Empirical = emp_prop, Theoretical = theo_prop),
        beside = TRUE, names.arg = support,
        col = c("grey70", "steelblue"),
        ylab = "Probability", xlab = "x",
        main = "Sample vs Fitted Truncated Poisson PMF")
legend("topright",
       legend = c("Empirical", paste0("Theoretical (lambda=", round(fit$lambda, 2), ")")),
       fill = c("grey70", "steelblue"), bty = "n")

## ----together-moments---------------------------------------------------------
sample_mode <- as.numeric(names(tab)[which.max(tab)])

comparison <- rbind(
  Sample = c(mean = mean(x), median = stats::median(x), mode = sample_mode),
  Theoretical = c(mean   = extruncpois(fit$lambda, a = a, b = b),
                  median = medtruncpois(fit$lambda, a = a, b = b),
                  mode   = suppressWarnings(modtruncpois(fit$lambda, a = a, b = b))[1])
)
round(comparison, 3)

## ----laplacesdemon-setup------------------------------------------------------
ld_available <- requireNamespace("LaplacesDemon", quietly = TRUE)

## ----laplacesdemon-lowtail, eval=ld_available---------------------------------
# Lower-tail probability P(X <= 7 | 2 <= X <= 10, lambda = 5)
ptruncpois(7, lambda = 5, a = 2, b = 10)
LaplacesDemon::ptrunc(7, spec = "pois", a = 2, b = 10, lambda = 5)

## ----laplacesdemon-uppertail, eval=ld_available-------------------------------
# Upper-tail probability P(X > 7 | 2 <= X <= 10, lambda = 5)

# truncpois: native lower.tail and log.p support, computed on log-scale
ptruncpois(7, lambda = 5, a = 2, b = 10, lower.tail = FALSE)
ptruncpois(7, lambda = 5, a = 2, b = 10, lower.tail = FALSE, log.p = TRUE)

# LaplacesDemon: manual subtraction and log() required
1 - LaplacesDemon::ptrunc(7, spec = "pois", a = 2, b = 10, lambda = 5)
log(1 - LaplacesDemon::ptrunc(7, spec = "pois", a = 2, b = 10, lambda = 5))

## ----laplacesdemon-qtrunc, eval=ld_available----------------------------------
# Upper-tail quantile: smallest x such that P(X > x) <= 0.1
qtruncpois(0.1, lambda = 5, a = 2, b = 10, lower.tail = FALSE)

# Same result using log-scale input
qtruncpois(log(0.1), lambda = 5, a = 2, b = 10, lower.tail = FALSE, log.p = TRUE)

# LaplacesDemon: no lower.tail support -- returns the lower-tail 10th percentile
# instead of the upper-tail 10th percentile
LaplacesDemon::qtrunc(0.1, spec = "pois", a = 2, b = 10, lambda = 5)

## ----laplacesdemon-moments, eval=ld_available---------------------------------
# truncpois: exact, closed-form
extruncpois(lambda = 5, a = 2, b = 10)
vartruncpois(lambda = 5, a = 2, b = 10)
medtruncpois(lambda = 5, a = 2, b = 10)
suppressWarnings(modtruncpois(lambda = 5, a = 2, b = 10))

# LaplacesDemon has no equivalent, so we simulate instead
set.seed(42)
samp <- LaplacesDemon::rtrunc(100000, spec = "pois", a = 2, b = 10, lambda = 5)
mean(samp)   # approximation -- varies with sample size and seed
var(samp)    # approximation -- varies with sample size and seed

